using System.Net;
using System.Net.Sockets;
using System.Text;

// UDP Chat + File Transfer
// Run as: dotnet run -- server
//      or: dotnet run -- client

const int Port = 5000;
const int ChunkSize = 40_000;
const string OutputFolder = "ReceivedFiles";

if (args.Length == 0 || (args[0].ToLower() != "server" && args[0].ToLower() != "client"))
{
    Console.WriteLine("Usage: dotnet run -- server  OR  dotnet run -- client");
    return;
}

using var udp = new UdpClient(args[0].ToLower() == "server" ? Port : 0);
var serverAddress = new IPEndPoint(IPAddress.Loopback, Port);

if (args[0].ToLower() == "server")
{
    Directory.CreateDirectory(OutputFolder);
    Console.WriteLine($"Server is listening on UDP port {Port}...");
    Console.WriteLine("Type a message and press Enter to reply to the latest client.");

    IPEndPoint? lastClient = null;
    var receiveTask = Task.Run(async () =>
    {
        var transfers = new Dictionary<string, SortedDictionary<int, byte[]>>();
        var expectedChunks = new Dictionary<string, int>();

        while (true)
        {
            UdpReceiveResult result = await udp.ReceiveAsync();
            lastClient = result.RemoteEndPoint;
            string message = Encoding.UTF8.GetString(result.Buffer);

            if (message.StartsWith("FILE|"))
            {
                string[] parts = message.Split('|');
                string name = Encoding.UTF8.GetString(Convert.FromBase64String(parts[1]));
                int count = int.Parse(parts[2]);
                transfers[name] = new SortedDictionary<int, byte[]>();
                expectedChunks[name] = count;
                Console.WriteLine($"Receiving file: {name} ({count} parts)");
            }
            else if (message.StartsWith("CHUNK|"))
            {
                string[] parts = message.Split('|', 4);
                string name = Encoding.UTF8.GetString(Convert.FromBase64String(parts[1]));
                int index = int.Parse(parts[2]);
                byte[] data = Convert.FromBase64String(parts[3]);

                if (!transfers.ContainsKey(name))
                    transfers[name] = new SortedDictionary<int, byte[]>();

                transfers[name][index] = data;

                if (expectedChunks.TryGetValue(name, out int total) &&
                    transfers[name].Count == total)
                {
                    string safeName = Path.GetFileName(name);
                    string path = Path.Combine(OutputFolder, safeName);
                    using var output = File.Create(path);
                    foreach (var part in transfers[name].Values)
                        await output.WriteAsync(part);

                    Console.WriteLine($"File saved: {path}");
                    transfers.Remove(name);
                    expectedChunks.Remove(name);
                }
            }
            else
            {
                Console.WriteLine($"Client: {message}");
            }
        }
    });

    while (true)
    {
        string? reply = Console.ReadLine();
        if (reply == null) break;
        if (lastClient != null)
            byte[] replyBytes = Encoding.UTF8.GetBytes(reply);\n            await udp.SendAsync(replyBytes, replyBytes.Length, lastClient);
        else
            Console.WriteLine("No client has connected yet.");
    }
}
else
{
    Console.WriteLine($"Client is ready. Server: {serverAddress}");
    Console.WriteLine("Type a message, /file full-path, or /quit.");

    var receiveTask = Task.Run(async () =>
    {
        while (true)
        {
            UdpReceiveResult result = await udp.ReceiveAsync();
            Console.WriteLine($"\nServer: {Encoding.UTF8.GetString(result.Buffer)}");
            Console.Write("> ");
        }
    });

    while (true)
    {
        Console.Write("> ");
        string? input = Console.ReadLine();
        if (input == null || input.Equals("/quit", StringComparison.OrdinalIgnoreCase))
            break;

        if (input.StartsWith("/file ", StringComparison.OrdinalIgnoreCase))
        {
            string path = input.Substring(6).Trim().Trim('"');
            if (!File.Exists(path))
            {
                Console.WriteLine("File not found.");
                continue;
            }

            byte[] fileBytes = await File.ReadAllBytesAsync(path);
            string fileName = Path.GetFileName(path);
            int totalChunks = (int)Math.Ceiling(fileBytes.Length / (double)ChunkSize);
            string encodedName = Convert.ToBase64String(Encoding.UTF8.GetBytes(fileName));

            byte[] header = Encoding.UTF8.GetBytes($"FILE|{encodedName}|{totalChunks}");\n            await udp.SendAsync(header, header.Length, serverAddress);

            for (int i = 0; i < totalChunks; i++)
            {
                byte[] chunk = fileBytes.Skip(i * ChunkSize).Take(ChunkSize).ToArray();
                string packet = $"CHUNK|{encodedName}|{i}|{Convert.ToBase64String(chunk)}";
                byte[] packetBytes = Encoding.UTF8.GetBytes(packet);\n                await udp.SendAsync(packetBytes, packetBytes.Length, serverAddress);
                await Task.Delay(10); // small pause between UDP packets
            }

            Console.WriteLine($"Sent file: {fileName}");
        }
        else
        {
            byte[] textBytes = Encoding.UTF8.GetBytes(input);\n            await udp.SendAsync(textBytes, textBytes.Length, serverAddress);
        }
    }
}
