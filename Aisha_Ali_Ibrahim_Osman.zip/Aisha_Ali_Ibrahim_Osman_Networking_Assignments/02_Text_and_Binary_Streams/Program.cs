using System.Text;

// Demonstration of text streams and binary streams.
string folder = "StreamFiles";
Directory.CreateDirectory(folder);

// 1) TEXT STREAM: write text, then read it.
string textPath = Path.Combine(folder, "message.txt");
using (StreamWriter writer = new StreamWriter(textPath, false, Encoding.UTF8))
{
    writer.WriteLine("Hello Aisha!");
    writer.WriteLine("This file demonstrates a text stream in C#.");
}

Console.WriteLine("TEXT STREAM:");
using (StreamReader reader = new StreamReader(textPath, Encoding.UTF8))
{
    string? line;
    while ((line = reader.ReadLine()) != null)
        Console.WriteLine(line);
}

// 2) BINARY STREAM: write values as bytes, then read them.
string binaryPath = Path.Combine(folder, "student.dat");
using (FileStream fs = new FileStream(binaryPath, FileMode.Create, FileAccess.Write))
using (BinaryWriter writer = new BinaryWriter(fs))
{
    writer.Write(101);              // student ID
    writer.Write("Aisha Ali");      // student name
    writer.Write(4.0);              // level
}

Console.WriteLine("\nBINARY STREAM:");
using (FileStream fs = new FileStream(binaryPath, FileMode.Open, FileAccess.Read))
using (BinaryReader reader = new BinaryReader(fs))
{
    int id = reader.ReadInt32();
    string name = reader.ReadString();
    double level = reader.ReadDouble();

    Console.WriteLine($"ID: {id}");
    Console.WriteLine($"Name: {name}");
    Console.WriteLine($"Level: {level}");
}

Console.WriteLine($"\nFiles were created in: {Path.GetFullPath(folder)}");
