@echo off
setlocal
echo Building the three C# assignments for Windows...
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET SDK was not found. Install the .NET 8 SDK, then run this file again.
  pause
  exit /b 1
)
dotnet publish "01_UDP_Chat_File_Transfer\UdpChat.csproj" -c Release -r win-x64 --self-contained false
dotnet publish "02_Text_and_Binary_Streams\StreamsDemo.csproj" -c Release -r win-x64 --self-contained false
dotnet publish "03_Database_to_Stream\DatabaseStream.csproj" -c Release -r win-x64 --self-contained false
echo.
echo Build finished. EXE files are inside each project's bin\Release\net8.0\win-x64\publish folder.
pause
